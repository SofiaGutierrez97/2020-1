//
//  comprasViewController.swift
//  Examen1Bandas
//
//  Created by Jerry Gordillo on 9/19/19.
//  Copyright © 2019 Sofía Gutiérrez. All rights reserved.
//

import UIKit

class comprasViewController: UIViewController {

    @IBOutlet weak var cantidadSouvenir1: UILabel!
    @IBOutlet weak var cantidadSouvenir2: UILabel!
    var hayCompra: Bool!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func adiosVistaCompras(for segue: UIStoryboardSegue){
        
    }

}
