//
//  ViewController.swift
//  Examen1
//
//  Created by Sofìa Gutièrrez on 9/20/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

